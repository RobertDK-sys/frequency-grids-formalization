# Planar Kakeya theorem in Lean 4 / Mathlib

Every set in the plane that contains a translate of the unit line segment in every direction has
Hausdorff dimension 2 (R. O. Davies, *Some remarks on the Kakeya problem*, Proc. Cambridge Philos.
Soc. **69** (1971) 417-421).

## The theorem

```lean
theorem planar_kakeya_hausdorff_dimension (E : Set Plane) (hE : IsKakeyaSet E) : dimH E = 2
```

where

```lean
abbrev Plane : Type := EuclideanSpace ℝ (Fin 2)
def IsKakeyaSet (E : Set Plane) : Prop := ∀ θ : ℝ, ∃ a : Plane, cseg θ a ⊆ E
def cseg (θ : ℝ) (a : Plane) : Set Plane :=
  {x | ∃ t ∈ Icc (-(1/2 : ℝ)) (1/2), x = a + t • dir θ}
```

and `dimH : Set X → ℝ≥0∞` is Mathlib's `MeasureTheory.dimH` (Hausdorff dimension).  The statement
is unconditional: no hypotheses other than `IsKakeyaSet E`, no `sorry`, no `axiom`, no
`native_decide`.

## How to check it

Toolchain: Lean 4.33.1, `leanprover/lean4:v4.33.1`, against Mathlib built at `/opt/mathlib`
(the archive does not include Mathlib).  There is no Lake project, because `/opt/mathlib` is not
writable; the modules are compiled directly with `lean`, in dependency order, with `LEAN_PATH`
pointing at the directory that holds `Kakeya/`:

```sh
cd kakeya-lean
for f in Basic Harmonic Angle Strip Tube SecondMoment Schur RowSum Operator \
         FiniteKakeya Dimension Hausdorff Cover Main; do
  LEAN_PATH=$PWD:$LEAN_PATH lean -o Kakeya/$f.olean Kakeya/$f.lean || echo "FAIL $f"
done
rm -f Kakeya/*.olean
```

The whole chain builds from scratch in about 35-40 s with exit status 0 and no errors.  The single
entry point is `Kakeya/Main.lean`; `import Kakeya.Main` pulls in everything.

To confirm the absence of unproved steps:

```lean
import Kakeya.Main
#print axioms Kakeya.planar_kakeya_hausdorff_dimension
-- 'Kakeya.planar_kakeya_hausdorff_dimension' depends on axioms: [propext, Classical.choice, Quot.sound]
```

Only Lean's three standard axioms appear; in particular there is no `sorryAx`.

## Proof architecture (the Córdoba route)

Davies' original proof goes through Marstrand's projection theorem and the product (slicing)
theorem for Hausdorff measures, neither of which is in Mathlib.  This development uses instead the
Córdoba route, which needs only tube geometry, a discrete operator (Schur) bound, and a
multi-scale counting argument.  All quantitative work is done in the sup-norm model
`Fin 2 → ℝ`; the two-plane transfer is by `WithLp.ofLp` (1-Lipschitz, √2-antilipschitz).

| module | contents |
|---|---|
| `Basic.lean` | `Plane`, `dir`, `cseg`, `IsKakeyaSet`, `planeTube`, the frame decomposition |
| `Harmonic.lean`, `Angle.lean` | the elementary trigonometric/harmonic sums |
| `Strip.lean` | strips and their measure |
| `Tube.lean` | rotation, rectangle, tube, tube measure and measurability |
| `SecondMoment.lean` | the second-moment (L²) bound for a family of tubes |
| `Schur.lean`, `RowSum.lean` | the Schur test and the row-sum estimate `M ≍ k 2^{-k}` |
| `Operator.lean` | `operator_bound_general`, `operator_bound`: `∑ᵢ (μ(Tᵢ ∩ S))² ≤ 2 M μ(S)` |
| `FiniteKakeya.lean` | the finite/discrete Kakeya estimate |
| `Hausdorff.lean` | covering bound ⟹ `μH[d] E ≠ 0` ⟹ `dimH E ≥ 2`; the `Plane`/`Fin 2 → ℝ` transfer |
| `Cover.lean` | the multi-scale covering bound `cover_sum_bound` (the heart of the argument) |
| `Dimension.lean` | the unconditional upper bound `dimH E ≤ 2` |
| `Main.lean` | `planar_kakeya_hausdorff_dimension` |

### The lower bound, in outline

For every `d < 2` there is a constant `c ≠ 0` such that *every* countable cover of a Kakeya set by
sets of diameter at most `1/16` satisfies `∑ₙ (ediam (t n))^d ≥ c` (`cover_sum_bound`).  This is
proved for the whole (typically unbounded) set `E`, with no ball reduction.

1. **Scale layers.**  For a cover `t`, put `J k = {n | 2^{-(k+1)} < ediam (t n) ≤ 2^{-k}}`, and
   refine `G k = ⋃_{n ∈ J k} closure (t n)` into the disjoint layers
   `H k = G k \ ⋃_{k' < k} G k'`, so `⋃ k H k = ⋃ k G k`.
2. **One-dimensional coverage.**  For each direction `θ`, the Kakeya segment gives a Kakeya point
   `a θ`, and the function
   `λ k θ = |{x ∈ Icc (-3/8) (3/8) | a θ + x • dirFi2 θ ∈ H k}|`
   satisfies `3/4 ≤ ∑ k, λ k θ` (the segment is covered by the `H k`, the degenerate scale `ρ = 0`
   being null).
3. **Tube lower bound.**  A thickened inner part of the segment lies in a tube of direction within
   `4·2^{-k}` of `θ`, and `volume_biUnion_closedBall_image_le` converts the one-dimensional
   coverage into `|T ∩ F k| ≥ c k |T| / 2`.
4. **Operator bound.**  `operator_bound` at scale `k`, with the Schur constant
   `2 h k + 20 (h k)² N k (1 + log N k) ≍ k 2^{-k}` for `N k = 2^k` equally spaced directions.
5. **Pigeonhole and assembly.**  A weighted pigeonhole over the `2^k` direction arcs produces
   enough "good" tubes; summing the per-scale inequalities over `k` and using the disjointness of
   the `J k` yields the bound.  The threshold weights `c k = δ ρ^k k`, with `ρ = 2^{-(2-d)/2}`,
   satisfy both `∑ k c k ≤ 1/4` and `c k² 2^{k(2-d)} / k = δ² k`; the constant `130000` is chosen
   to make the per-scale identity exact at `k = 1`.
6. **From the covering bound to the dimension.**  `hausdorffMeasure_ne_zero_of_cover_bound` turns
   the covering bound into `μH[d] E ≠ 0` for every `d < 2`, and
   `le_two_dimH_of_hausdorffMeasure_ne_zero` into `2 ≤ dimH E`.  The upper bound is
   `dimH_le_two_fin2`.

## Provenance

- Lean 4.33.1 (commit `819816b2e0a3bf405af45ae5c7af2491d8f5bee6`).
- Mathlib from the `/opt/mathlib` checkout of the development VM (source not included here).
- Files: 14 modules, ~2800 lines.

## Note on `IsKakeyaSet`

`IsKakeyaSet E` is genuinely restrictive (a singleton is not a Kakeya set), and the conclusion
`dimH E = 2` is not a tautology (a point has dimension `0`).  The hypothesis also makes `E`
nonempty, which supplies the `d = 0` case of the Hausdorff-measure hypothesis used in `Main.lean`.
